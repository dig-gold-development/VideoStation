package com.site.vs.videostation.base;

/**
 * @author zhangbb
 * @date 2016/10/20
 */
public interface BaseModel {
}

package com.site.vs.videostation.base;

/**
 * @author zhangbb
 * @date 2016/7/28.
 */
public interface BaseView {

    void showLoading();

    void hideLoading();

}

package com.site.vs.videostation.entity;

/**
 * Author       zhusx
 * Email        327270607@qq.com
 * Created      2016/12/19 10:20
 */

public class Category {
    public int move_id;
    public int tv_id;
    public int comic_id;
    public int arts_id;
}

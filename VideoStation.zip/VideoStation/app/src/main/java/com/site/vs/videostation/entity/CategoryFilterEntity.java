package com.site.vs.videostation.entity;

/**
 * @author zhangbb
 * @date 2016/12/21
 */
public class CategoryFilterEntity {

    public String tid;
    public String tname;
    public String pic;

}

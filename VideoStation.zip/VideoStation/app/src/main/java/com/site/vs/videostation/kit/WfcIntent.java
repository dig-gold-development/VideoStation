package com.site.vs.videostation.kit;

public interface WfcIntent {
    String ACTION_MAIN = "cn.wildfirechat.chat.main";
    String ACTION_CONVERSATION = "cn.wildfirechat.chat.conversation";
    String ACTION_CONTACT = "cn.wildfirechat.chat.contact";
    String ACTION_USER_INFO = "cn.wildfirechat.chat.user.info";
    String ACTION_GROUP_INFO = "cn.wildfirechat.chat.group.info";
    String ACTION_VOIP_SINGLE = "cn.wildfirechat.kit.chat.voip.single";
}

package com.site.vs.videostation.kit;

public interface WfcScheme {
    String QR_CODE_PREFIX_PC_SESSION = "wildfirechat://pcsession/";
    String QR_CODE_PREFIX_USER = "wildfirechat://user/";
    String QR_CODE_PREFIX_GROUP = "wildfirechat://group/";
    String QR_CODE_PREFIX_CHANNEL = "wildfirechat://channel/";
}

package com.site.vs.videostation.kit.common;

/**
 * 当{@link androidx.lifecycle.ViewModel} 需要跨{@link android.app.Activity} 共享数据时使用
 */
public interface AppScopeViewModel {
}

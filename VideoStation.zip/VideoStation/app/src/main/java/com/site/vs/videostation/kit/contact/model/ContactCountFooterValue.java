package com.site.vs.videostation.kit.contact.model;

public class ContactCountFooterValue extends FooterValue {
}

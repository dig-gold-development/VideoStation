package com.site.vs.videostation.kit.contact.model;

public class FooterValue {
}

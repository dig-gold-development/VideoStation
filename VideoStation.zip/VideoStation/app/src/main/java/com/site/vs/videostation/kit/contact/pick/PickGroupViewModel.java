package com.site.vs.videostation.kit.contact.pick;

import androidx.lifecycle.ViewModel;

// TODO
public class PickGroupViewModel extends ViewModel {
}

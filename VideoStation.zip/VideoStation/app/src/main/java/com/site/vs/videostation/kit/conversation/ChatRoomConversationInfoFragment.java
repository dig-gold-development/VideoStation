package com.site.vs.videostation.kit.conversation;

import androidx.fragment.app.Fragment;

// TODO
public class ChatRoomConversationInfoFragment extends Fragment {
}

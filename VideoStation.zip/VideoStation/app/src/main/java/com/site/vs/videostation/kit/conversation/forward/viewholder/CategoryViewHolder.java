package com.site.vs.videostation.kit.conversation.forward.viewholder;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class CategoryViewHolder extends RecyclerView.ViewHolder {
    public CategoryViewHolder(View itemView) {
        super(itemView);
    }

    public void onBind() {

    }
}

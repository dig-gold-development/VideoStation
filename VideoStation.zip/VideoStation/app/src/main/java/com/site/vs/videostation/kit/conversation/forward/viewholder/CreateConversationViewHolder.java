package com.site.vs.videostation.kit.conversation.forward.viewholder;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class CreateConversationViewHolder extends RecyclerView.ViewHolder {
    public CreateConversationViewHolder(View itemView) {
        super(itemView);
    }
}

package com.site.vs.videostation.kit.conversation.message.viewholder;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class LoadingViewHolder extends RecyclerView.ViewHolder {
    public LoadingViewHolder(View itemView) {
        super(itemView);
    }
}

package com.site.vs.videostation.kit.conversation.message.viewholder;

public interface MessageContextMenuItemTags {
    String TAG_RECALL = "recall";
    String TAG_DELETE = "delete";
    String TAG_CLIP = "clip";
    String TAG_FORWARD = "forward";
    String TAG_CHANEL_PRIVATE_CHAT = "chanelPrivateChat";
}

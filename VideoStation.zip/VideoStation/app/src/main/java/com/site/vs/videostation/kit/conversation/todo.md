1. inputPanel
2. menu group ```android:animateLayoutChanges="true" ```

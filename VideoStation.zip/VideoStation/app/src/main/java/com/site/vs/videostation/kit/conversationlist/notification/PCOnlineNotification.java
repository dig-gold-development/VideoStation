package com.site.vs.videostation.kit.conversationlist.notification;

public class PCOnlineNotification extends StatusNotification {
}

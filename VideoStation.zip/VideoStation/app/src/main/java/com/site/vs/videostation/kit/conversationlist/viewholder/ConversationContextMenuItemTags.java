package com.site.vs.videostation.kit.conversationlist.viewholder;

public interface ConversationContextMenuItemTags {
    String TAG_REMOVE = "remove";
    String TAG_CLEAR = "clear";
    String TAG_TOP = "stick_top";
    String TAG_CANCEL_TOP = "cancel_stick_top";
    String TAG_UNSUBSCRIBE = "unSubscribe_channel";
}

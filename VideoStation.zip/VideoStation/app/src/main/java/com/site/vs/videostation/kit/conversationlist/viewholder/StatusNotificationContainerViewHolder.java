package com.site.vs.videostation.kit.conversationlist.viewholder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import com.site.vs.videostation.kit.annotation.LayoutRes;
import com.site.vs.videostation.kit.conversationlist.notification.StatusNotification;
import com.site.vs.videostation.kit.conversationlist.notification.StatusNotificationManager;
import com.site.vs.videostation.kit.conversationlist.notification.viewholder.StatusNotificationViewHolder;
import com.site.vs.videostation.R;

public class StatusNotificationContainerViewHolder extends RecyclerView.ViewHolder {
    @BindView(R.id.notificationContainerLayout)
    LinearLayout containerLayout;

    public StatusNotificationContainerViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }

    public void onBind(Fragment fragment, View itemView, List<StatusNotification> statusNotifications) {
        LayoutInflater layoutInflater = LayoutInflater.from(fragment.getContext());

        containerLayout.removeAllViews();
        StatusNotificationViewHolder statusNotificationViewHolder;
        View view;
        for (StatusNotification notification : statusNotifications) {
            try {
                Class<? extends StatusNotificationViewHolder> holderClass = StatusNotificationManager.getInstance().getNotificationViewHolder(notification);
                Constructor constructor = holderClass.getConstructor(Fragment.class);
                statusNotificationViewHolder = (StatusNotificationViewHolder) constructor.newInstance(fragment);
                LayoutRes layoutRes = holderClass.getAnnotation(LayoutRes.class);
                view = layoutInflater.inflate(layoutRes.resId(), (ViewGroup) itemView, false);
                ButterKnife.bind(statusNotificationViewHolder, view);

                statusNotificationViewHolder.onBind(view, notification);
                containerLayout.addView(view);
                // TODO add divider
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
    }
}

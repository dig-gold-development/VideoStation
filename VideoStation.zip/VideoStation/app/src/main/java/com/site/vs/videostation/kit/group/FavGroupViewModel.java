package com.site.vs.videostation.kit.group;

import androidx.lifecycle.ViewModel;

public class FavGroupViewModel extends ViewModel {
}

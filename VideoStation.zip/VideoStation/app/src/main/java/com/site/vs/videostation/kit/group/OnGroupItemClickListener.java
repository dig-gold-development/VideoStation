package com.site.vs.videostation.kit.group;

import cn.wildfirechat.model.GroupInfo;

public interface OnGroupItemClickListener {
    void onGroupClick(GroupInfo groupInfo);
}

package com.site.vs.videostation.kit.utils.portrait;

class CombineBitmapEntity {
    public float x;
    public float y;
    public float width;
    public float height;
    public static int divide = 1;
    public int index = -1;

    @Override
    public String toString() {
        return "MyBitmap [x=" + x + ", y=" + y + ", width=" + width
                + ", height=" + height + ", divide=" + divide + ", index="
                + index + "]";
    }
}


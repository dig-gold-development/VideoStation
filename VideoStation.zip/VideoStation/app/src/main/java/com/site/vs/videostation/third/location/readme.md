这是一个非常参考，代码风格和其他的也不一样，仅供参考
代码是基于，[LQRWeChat](https://github.com/GitLqr/LQRWeChat)
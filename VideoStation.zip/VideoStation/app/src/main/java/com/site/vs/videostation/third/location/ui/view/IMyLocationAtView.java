package com.site.vs.videostation.third.location.ui.view;


import androidx.recyclerview.widget.RecyclerView;

public interface IMyLocationAtView {
    RecyclerView getRvPOI();
}

package com.site.vs.videostation.widget;

import android.content.Context;
import android.util.AttributeSet;

import com.zhusx.core.widget.view.Lib_Widget_TextView;

/**
 * Author       zhusx
 * Email        327270607@qq.com
 * Created      2016/10/17 17:21
 */

public class ShapeTextView extends Lib_Widget_TextView {
    public ShapeTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}

package com.site.vs.videostation.widget.refreshRecycler.ptr;

public interface OnScrollBottomListener {
    public void onScorllBootom();
}
